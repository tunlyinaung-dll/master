# HelloWorldGoServer
GO + Docker + unit tests


## Running the app locally

```bash
$ go build
$ ./go-sample-app
2019/02/03 11:38:11 Starting Server
```

```bash
$ curl http://localhost:8080?name=Nofar
Hello, Nofar 
Test
``` 

  
   
   
    
         
          
               
 
   
  
